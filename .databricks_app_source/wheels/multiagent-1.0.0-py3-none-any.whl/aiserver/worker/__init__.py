"""Standalone delegation-worker process."""
