"""Orchestrate multi-agent request routing handlers."""

import asyncio
import logging
from collections.abc import AsyncGenerator
from contextlib import AsyncExitStack
from dataclasses import asdict, dataclass
from time import monotonic
from typing import Any, cast
from uuid import uuid4

import mlflow
from agents import Runner, set_default_openai_api, set_default_openai_client
from agents.exceptions import UserError
from agents.tracing import add_trace_processor, set_trace_processors
from databricks_openai import AsyncDatabricksOpenAI
from deepeval.openai_agents import DeepEvalTracingProcessor
from mlflow.genai.agent_server import invoke, stream
from mlflow.types.responses import (
    ResponsesAgentRequest,
    ResponsesAgentResponse,
    ResponsesAgentStreamEvent,
)

from aiserver.application.guardrails.checks import truncate_response_text
from aiserver.application.orchestration.model import select_model
from aiserver.application.orchestration.routing import build_route_plan
from aiserver.application.runtime.identity import get_session_id
from aiserver.application.runtime.requests import extract_mcp_errors, to_messages
from aiserver.application.runtime.streaming import process_agent_stream_events
from aiserver.bootstrap.container import get_handler_dependencies
from aiserver.config.settings import get_settings
from aiserver.contracts.responses import (
    HumanApprovalState,
    OpenAIAgentRunMetadata,
    ResponseEnvelope,
    RoutePlan,
)
from aiserver.contracts.subagents import SUBAGENTS, SubagentConfig

SETTINGS = get_settings()
HANDLER_DEPS = get_handler_dependencies()


def _build_openai_client() -> AsyncDatabricksOpenAI:
    """Build Databricks OpenAI client with optional runtime overrides.

    Precedence: an explicit `base_url` wins, then native Unity AI Gateway V2
    routing, then MLflow-compatible AI Gateway routing, else the legacy direct
    `/serving-endpoints` call. Model name strings (for example
    `databricks-claude-sonnet-5`) are unchanged across all four modes; the
    `system.ai.<model>` name is a Unity Catalog governance/lineage identity,
    not a valid `model` value for chat/responses calls.
    """
    kwargs: dict[str, Any] = {}
    if SETTINGS.openai_base_url.strip():
        kwargs["base_url"] = SETTINGS.openai_base_url.strip()
    elif SETTINGS.openai_use_ai_gateway_native_api:
        kwargs["use_ai_gateway_native_api"] = True
    elif SETTINGS.openai_use_ai_gateway:
        kwargs["use_ai_gateway"] = True
    if SETTINGS.openai_timeout_seconds > 0:
        kwargs["timeout"] = SETTINGS.openai_timeout_seconds
    return AsyncDatabricksOpenAI(**kwargs)


_client = _build_openai_client()
set_default_openai_client(_client)
set_default_openai_api("responses")
set_trace_processors([])
# Additive to mlflow.openai.autolog(): deepeval hooks the Agents SDK span
# pipeline directly rather than patching the OpenAI client, so both coexist.
add_trace_processor(DeepEvalTracingProcessor())
cast(Any, mlflow).openai.autolog()
logger = logging.getLogger(__name__)
if not SUBAGENTS:
    logger.warning("No subagents configured. The orchestrator will run without routing tools.")


@dataclass(frozen=True)
class RequestStage:
    """Represent prepared request inputs for pipeline execution."""

    request: ResponsesAgentRequest
    runtime_auth: Any
    messages: list[Any]
    conversation_id: str | None = None


@dataclass(frozen=True)
class ConnectedStage:
    """Represent connected tooling and agent state for request execution."""

    runtime_auth: Any
    unavailable: list[str]
    route_plan: RoutePlan
    openai_run: OpenAIAgentRunMetadata
    agent: Any


@dataclass(frozen=True)
class InvokeFinalizedStage:
    """Represent finalized invoke output and metadata after guardrails."""

    output_items: list[dict[str, Any]]
    unavailable: list[str]
    envelope: ResponseEnvelope


@dataclass(frozen=True)
class StreamExecutedStage:
    """Represent buffered stream output with precomputed guardrail inputs."""

    event_count: int
    buffered_events: list[Any]
    streamed_text_parts: list[str]
    used_subagents: list[SubagentConfig]
    has_tool_activity: bool


@dataclass(frozen=True)
class StreamFinalizedStage:
    """Represent finalized stream output and guardrail decision."""

    event_count: int
    buffered_events: list[Any]
    source_suffix: str
    unavailable: list[str]
    guardrail_blocked: bool
    guardrail_reasons: tuple[str, ...]
    envelope: ResponseEnvelope


def _prepare_request_stage(request: ResponsesAgentRequest) -> RequestStage:
    """Build request-scoped auth context and normalized messages.

    Args:
        request: Incoming Responses API request.

    Returns:
        Prepared request stage with runtime auth context and messages.
    """
    input_guardrail = HANDLER_DEPS.input_guardrails_evaluator(
        request.input,
        max_input_chars=SETTINGS.max_input_chars,
    )
    if input_guardrail.blocked:
        HANDLER_DEPS.message_bus.publish(
            "request.guardrail.blocked",
            {
                "phase": "input",
                "reasons": list(input_guardrail.reasons),
                "character_count": input_guardrail.character_count,
            },
        )
        raise UserError(
            "Request blocked by input guardrails: " + ", ".join(input_guardrail.reasons)
        )

    runtime_auth = HANDLER_DEPS.runtime_auth_builder(request, SUBAGENTS, _client)
    messages = to_messages(request.input)
    return RequestStage(
        request=request,
        runtime_auth=runtime_auth,
        messages=messages,
        conversation_id=get_session_id(request),
    )


def _request_persona(request: ResponsesAgentRequest) -> str | None:
    """Return the persona explicitly provided on a request, if any."""
    custom_inputs = request.custom_inputs
    if isinstance(custom_inputs, dict):
        raw = custom_inputs.get("persona")
        if isinstance(raw, str) and raw.strip():
            return raw.strip().lower()
    return None


def _apply_remembered_persona(request: ResponsesAgentRequest, conversation_id: str | None) -> None:
    """Fill in a remembered persona from conversation memory when none was provided."""
    if not conversation_id or _request_persona(request):
        return
    remembered = HANDLER_DEPS.memory.get_persona_preference(conversation_id)
    if not remembered:
        return
    merged = dict(request.custom_inputs) if isinstance(request.custom_inputs, dict) else {}
    merged["persona"] = remembered
    request.custom_inputs = merged


def _restore_conversation_memory(
    request: ResponsesAgentRequest, conversation_id: str | None
) -> None:
    """Prepend durable conversation history when the client sends one turn."""
    if not conversation_id or SETTINGS.memory_max_turns <= 0:
        return

    remembered_turns = HANDLER_DEPS.memory.recent_turns(conversation_id, SETTINGS.memory_max_turns)
    if not remembered_turns:
        return

    input_items = list(request.input)
    existing_turns = []
    for item in input_items:
        data = item.model_dump() if hasattr(item, "model_dump") else item
        if (
            isinstance(data, dict)
            and data.get("role") in {"user", "assistant"}
            and isinstance(data.get("content"), str)
        ):
            existing_turns.append(data)
    history_length = len(remembered_turns)
    if any(
        existing_turns[index : index + history_length] == remembered_turns
        for index in range(len(existing_turns) - history_length + 1)
    ):
        return
    request.input = [*remembered_turns, *input_items]


def _extract_user_question(messages: list[Any]) -> str:
    """Extract the latest user message text from normalized request messages."""
    for message in reversed(messages):
        data = message.model_dump() if hasattr(message, "model_dump") else message
        if isinstance(data, dict) and data.get("role") == "user":
            return str(data.get("content", ""))
    return ""


def _extract_last_assistant_text(output_items: list[dict[str, Any]]) -> str:
    """Extract the last assistant message text from finalized output items."""
    for item in reversed(output_items):
        if not isinstance(item, dict) or item.get("role") != "assistant":
            continue
        content = item.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            texts = [
                block.get("text", "") if isinstance(block, dict) else str(block)
                for block in content
            ]
            return " ".join(filter(None, texts))
    return ""


def _persist_memory_turns(
    conversation_id: str | None,
    persona: str | None,
    *,
    question: str,
    answer: str,
) -> None:
    """Persist the latest user/assistant turns and persona preference to memory."""
    if not conversation_id:
        return
    if question:
        HANDLER_DEPS.memory.save_turn(conversation_id, persona, "user", question)
    if answer:
        HANDLER_DEPS.memory.save_turn(conversation_id, persona, "assistant", answer)
    if persona:
        HANDLER_DEPS.memory.save_persona_preference(conversation_id, persona)


def _select_route_tools(
    tools: list[Any],
    route_candidates: list[SubagentConfig],
    route_reason: str,
) -> list[Any]:
    """Select function tools without leaking them into confident MCP routes."""
    candidate_names = {candidate.name for candidate in route_candidates}
    selected = [
        tool
        for tool in tools
        if str(getattr(tool, "name", getattr(tool, "__name__", ""))).removeprefix("query_")
        in candidate_names
    ]
    if not selected and route_reason in {"ambiguous_fallback", "low_confidence_fallback"}:
        return tools
    return selected


def _tool_name(tool: Any) -> str:
    """Return a stable display name for an OpenAI function or MCP tool handle."""
    return str(getattr(tool, "name", getattr(tool, "__name__", ""))).strip()


def _stream_progress_event(stage: str) -> ResponsesAgentStreamEvent:
    """Keep the response stream active without releasing unguarded answer text."""
    return cast(
        Any,
        {
            "type": "response.progress",
            "stage": stage,
        },
    )


def _publish_stream_stage(stage: str, started_at: float) -> None:
    """Publish a timing checkpoint for the streamed request lifecycle."""
    HANDLER_DEPS.message_bus.publish(
        "request.stream.stage.completed",
        {
            "stage": stage,
            "elapsed_ms": (monotonic() - started_at) * 1000,
        },
    )


async def _connect_request_stage(
    stack: AsyncExitStack,
    prepared: RequestStage,
) -> ConnectedStage:
    """Connect MCP servers and build the orchestrator agent.

    Args:
        stack: Async context stack used for MCP server lifecycle.
        prepared: Prepared request stage.

    Returns:
        Connected stage with orchestrator agent and unavailable details.
    """
    question = ""
    for message in reversed(prepared.messages):
        data = message.model_dump() if hasattr(message, "model_dump") else message
        if isinstance(data, dict) and data.get("role") == "user":
            question = str(data.get("content", ""))
            break
    route_plan, route_candidates = build_route_plan(
        question,
        prepared.runtime_auth.policy_allowed_subagents,
        conversation_id=prepared.conversation_id,
    )
    candidate_names = {candidate.name for candidate in route_candidates}
    planned_mcp_servers = [
        server
        for server in prepared.runtime_auth.mcp_servers
        if str(getattr(server, "name", "")).split(":", 1)[-1] in candidate_names
    ]
    if (
        not planned_mcp_servers
        and prepared.runtime_auth.mcp_servers
        and route_plan.reason == "ambiguous_fallback"
    ):
        planned_mcp_servers = prepared.runtime_auth.mcp_servers
    servers, unavailable_health = await HANDLER_DEPS.mcp_connector(stack, planned_mcp_servers)
    unavailable = prepared.runtime_auth.unavailable_auth + unavailable_health
    candidate_tools = _select_route_tools(
        prepared.runtime_auth.subagent_tools,
        route_candidates,
        route_plan.reason,
    )
    model_selection = select_model(question, SETTINGS)
    selected_tool_names = tuple(
        sorted(
            name
            for name in (
                *(_tool_name(tool) for tool in candidate_tools),
                *(str(getattr(server, "name", "")).strip() for server in servers),
            )
            if name
        )
    )
    openai_run = OpenAIAgentRunMetadata(
        run_id=str(uuid4()),
        model=model_selection.model,
        model_task_type=model_selection.task_type,
        model_reason=model_selection.reason,
        model_rationale=model_selection.rationale,
        candidate_subagents=tuple(route_plan.candidates),
        selected_tool_names=selected_tool_names,
        unavailable_tool_details=tuple(unavailable),
        ai_gateway_enabled=bool(
            SETTINGS.openai_base_url.strip()
            or SETTINGS.openai_use_ai_gateway_native_api
            or SETTINGS.openai_use_ai_gateway
        ),
    )
    agent = HANDLER_DEPS.orchestrator_factory(
        model_selection.model,
        route_candidates,
        servers,
        candidate_tools,
        unavailable,
    )
    HANDLER_DEPS.message_bus.publish(
        "routing.plan.selected",
        {
            "candidates": list(route_plan.candidates),
            "reason": route_plan.reason,
            "confidence": route_plan.confidence,
            "requires_evidence": route_plan.requires_evidence,
            "model": model_selection.model,
            "model_task_type": model_selection.task_type,
            "model_reason": model_selection.reason,
            "model_rationale": model_selection.rationale,
            "selected_tool_names": list(selected_tool_names),
            "openai_api": openai_run.api,
            "ai_gateway_enabled": openai_run.ai_gateway_enabled,
        },
    )
    HANDLER_DEPS.message_bus.publish(
        "openai.agent.run.started",
        asdict(openai_run),
    )
    return ConnectedStage(
        runtime_auth=prepared.runtime_auth,
        unavailable=unavailable,
        route_plan=route_plan,
        openai_run=openai_run,
        agent=agent,
    )


_TRANSIENT_RETRIES = 2
_RETRY_BACKOFF_SECONDS = 1.0


def _is_transient(exc: BaseException) -> bool:
    """Return True for connection errors worth retrying."""
    name = type(exc).__name__
    return "APIConnectionError" in name or "ConnectionError" in name


async def _execute_invoke_stage(
    connected: ConnectedStage,
    messages: list[Any],
) -> Any:
    """Run the orchestrator agent for invoke with retry on transient errors."""
    last_exc: BaseException | None = None
    for attempt in range(_TRANSIENT_RETRIES + 1):
        try:
            return await Runner.run(connected.agent, messages)
        except Exception as exc:
            if not _is_transient(exc) or attempt >= _TRANSIENT_RETRIES:
                raise
            last_exc = exc
            logger.warning("Transient error on invoke attempt %d, retrying: %s", attempt + 1, exc)
            await asyncio.sleep(_RETRY_BACKOFF_SECONDS * (attempt + 1))
    raise last_exc  # unreachable but satisfies type checker


def _finalize_invoke_stage(
    result: Any,
    connected: ConnectedStage,
) -> InvokeFinalizedStage:
    """Apply governed source formatting and guardrails to invoke output.

    Args:
        result: Runner output from agent execution.
        connected: Connected invoke stage with runtime auth context.

    Returns:
        Finalized invoke stage containing output items and unavailable details.

    Raises:
        UserError: If response is blocked by guardrails.
    """
    response_text = _response_text_from_items(result.new_items)
    output_items = cast(Any, [item.to_input_item() for item in result.new_items])
    guardrail_subagents = _guardrail_scope_subagents(
        output_items,
        connected.runtime_auth.policy_allowed_subagents,
    )
    approval_state = _approval_state_for_subagents(guardrail_subagents)
    source_suffix = _governed_source_suffix_with_fallback(
        output_items,
        guardrail_subagents,
    )
    if source_suffix and source_suffix not in response_text:
        response_text += source_suffix
        output_items = _append_source_to_output_items(output_items, source_suffix)
    if approval_state.required and approval_state.status == "pending":
        approval_message = (
            "\n\nApproval required: this recommendation is pending manager review before any "
            "operational action or dispatch recommendation is sent."
        )
        if approval_message not in response_text:
            response_text += approval_message
            output_items = _append_approval_message_to_output_items(output_items, approval_state)
    response_text, truncated = truncate_response_text(
        response_text,
        max_response_chars=SETTINGS.max_response_chars,
    )
    if truncated:
        output_items = _truncate_output_items(
            output_items,
            max_response_chars=SETTINGS.max_response_chars,
        )
    guardrail = HANDLER_DEPS.guardrails_evaluator(
        response_text,
        guardrail_subagents,
    )
    if "evidence_required" in guardrail.reasons and guardrail_subagents:
        evidence_suffix = "\n\nSource: governed response; source metadata was unavailable in the final output item."
        if evidence_suffix not in response_text:
            response_text += evidence_suffix
            output_items = _append_source_to_output_items(output_items, evidence_suffix)
            guardrail = HANDLER_DEPS.guardrails_evaluator(
                response_text,
                guardrail_subagents,
            )
    if guardrail.blocked:
        HANDLER_DEPS.message_bus.publish(
            "response.guardrail.blocked",
            {
                "reasons": list(guardrail.reasons),
                "truncated": truncated,
                "openai_run": asdict(connected.openai_run),
            },
        )
        _publish_openai_run_completed(
            ResponseEnvelope(
                status="blocked",
                answer_chars=len(response_text),
                truncated=truncated,
                route_plan=connected.route_plan,
                openai_run=connected.openai_run,
                guardrail_reasons=guardrail.reasons,
                source_metadata=(source_suffix,) if source_suffix else (),
                approval_state=approval_state,
            )
        )
        raise UserError("Response blocked by guardrails: " + ", ".join(guardrail.reasons))
    HANDLER_DEPS.message_bus.publish(
        "response.guardrail.passed",
        {
            "reasons": list(guardrail.reasons),
            "truncated": truncated,
            "openai_run": asdict(connected.openai_run),
        },
    )
    return InvokeFinalizedStage(
        output_items=output_items,
        unavailable=connected.unavailable,
        envelope=ResponseEnvelope(
            status="truncated" if truncated else "succeeded",
            answer_chars=len(response_text),
            truncated=truncated,
            route_plan=connected.route_plan,
            openai_run=connected.openai_run,
            guardrail_reasons=guardrail.reasons,
            source_metadata=(source_suffix,) if source_suffix else (),
            approval_state=approval_state,
        ),
    )


async def _execute_stream_stage(
    connected: ConnectedStage,
    messages: list[Any],
) -> StreamExecutedStage:
    """Run streamed orchestration with retry on transient errors."""
    last_exc: BaseException | None = None
    for attempt in range(_TRANSIENT_RETRIES + 1):
        try:
            return await _execute_stream_stage_inner(connected, messages)
        except Exception as exc:
            if not _is_transient(exc) or attempt >= _TRANSIENT_RETRIES:
                raise
            last_exc = exc
            logger.warning("Transient error on stream attempt %d, retrying: %s", attempt + 1, exc)
            await asyncio.sleep(_RETRY_BACKOFF_SECONDS * (attempt + 1))
    raise last_exc  # unreachable


async def _execute_stream_stage_inner(
    connected: ConnectedStage,
    messages: list[Any],
) -> StreamExecutedStage:
    """Run streamed orchestration and precompute finalization inputs."""
    result = Runner.run_streamed(connected.agent, input=messages)
    event_count = 0
    buffered_events: list[Any] = []
    streamed_text_parts: list[str] = []
    used_subagents: list[SubagentConfig] = []
    seen_subagents: set[str] = set()
    has_tool_activity = False
    allowed_subagents = connected.runtime_auth.policy_allowed_subagents

    async for event in process_agent_stream_events(result.stream_events()):
        event_count += 1
        buffered_events.append(event)
        text = _text_from_stream_event(event)
        if text:
            streamed_text_parts.append(text)

        if not isinstance(event, dict):
            continue

        if _payload_has_tool_activity(event):
            has_tool_activity = True

        for candidate in _candidate_tool_names(event):
            subagent = _resolve_subagent(candidate, allowed_subagents)
            if subagent is None or subagent.name in seen_subagents:
                continue
            seen_subagents.add(subagent.name)
            used_subagents.append(subagent)

    return StreamExecutedStage(
        event_count=event_count,
        buffered_events=buffered_events,
        streamed_text_parts=streamed_text_parts,
        used_subagents=used_subagents,
        has_tool_activity=has_tool_activity,
    )


def _finalize_stream_stage(
    executed: StreamExecutedStage,
    connected: ConnectedStage,
) -> StreamFinalizedStage:
    """Apply governed source handling and guardrails to buffered stream output.

    Args:
        executed: Buffered stream execution stage.
        connected: Connected stage with runtime auth context.

    Returns:
        Finalized stream stage with guardrail decision and output metadata.
    """
    if executed.used_subagents:
        guardrail_subagents = executed.used_subagents
    elif executed.has_tool_activity:
        guardrail_subagents = [
            subagent
            for subagent in connected.runtime_auth.policy_allowed_subagents
            if subagent.requires_evidence
        ]
    else:
        guardrail_subagents = []

    source_suffix = _governed_source_suffix(executed.used_subagents)
    if not source_suffix and guardrail_subagents and executed.has_tool_activity:
        source_suffix = "\n\nSource: tool-backed governed response."

    approval_state = _approval_state_for_subagents(guardrail_subagents)
    streamed_text_parts = list(executed.streamed_text_parts)
    stream_text = "\n".join(streamed_text_parts)
    if source_suffix and source_suffix not in stream_text:
        streamed_text_parts.append(source_suffix)
        stream_text = "\n".join(streamed_text_parts)
    if approval_state.required and approval_state.status == "pending":
        approval_message = (
            "\n\nApproval required: this recommendation is pending manager review before any "
            "operational action or dispatch recommendation is sent."
        )
        if approval_message not in stream_text:
            streamed_text_parts.append(approval_message)
            stream_text = "\n".join(streamed_text_parts)

    stream_text, truncated = truncate_response_text(
        stream_text,
        max_response_chars=SETTINGS.max_response_chars,
    )

    guardrail = HANDLER_DEPS.guardrails_evaluator(
        stream_text,
        guardrail_subagents,
    )
    if "evidence_required" in guardrail.reasons and guardrail_subagents:
        evidence_suffix = "\n\nSource: governed response; source metadata was unavailable in the final output item."
        if evidence_suffix not in stream_text:
            streamed_text_parts.append(evidence_suffix)
            stream_text = "\n".join(streamed_text_parts)
            guardrail = HANDLER_DEPS.guardrails_evaluator(
                stream_text,
                guardrail_subagents,
            )
    if guardrail.blocked:
        HANDLER_DEPS.message_bus.publish(
            "response.guardrail.blocked",
            {
                "reasons": list(guardrail.reasons),
                "mode": "stream",
                "truncated": truncated,
                "openai_run": asdict(connected.openai_run),
            },
        )
    else:
        HANDLER_DEPS.message_bus.publish(
            "response.guardrail.passed",
            {
                "reasons": list(guardrail.reasons),
                "mode": "stream",
                "truncated": truncated,
                "openai_run": asdict(connected.openai_run),
            },
        )

    return StreamFinalizedStage(
        event_count=executed.event_count,
        buffered_events=executed.buffered_events,
        source_suffix=source_suffix,
        unavailable=connected.unavailable,
        guardrail_blocked=guardrail.blocked,
        guardrail_reasons=guardrail.reasons,
        envelope=ResponseEnvelope(
            status="blocked" if guardrail.blocked else ("truncated" if truncated else "succeeded"),
            answer_chars=len(stream_text),
            truncated=truncated,
            route_plan=connected.route_plan,
            openai_run=connected.openai_run,
            guardrail_reasons=guardrail.reasons,
            source_metadata=(source_suffix,) if source_suffix else (),
            approval_state=approval_state,
        ),
    )


def _response_text_from_items(items: list[Any]) -> str:
    """Extract plain text from output items for guardrail evaluation."""
    chunks: list[str] = []
    for item in items:
        data = item.to_input_item() if hasattr(item, "to_input_item") else item
        if not isinstance(data, dict):
            continue
        content = data.get("content")
        if isinstance(content, str):
            chunks.append(content)
            continue
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict):
                    text = block.get("text")
                    if isinstance(text, str) and text.strip():
                        chunks.append(text)
    return "\n".join(chunks).strip()


def _text_from_stream_event(event: Any) -> str:
    """Extract text fragments from normalized stream events."""
    data = event.model_dump() if hasattr(event, "model_dump") else event
    if not isinstance(data, dict):
        return ""

    if data.get("type") == "response.output_text.delta":
        delta = data.get("delta")
        return delta if isinstance(delta, str) else ""

    item = data.get("item")
    if isinstance(item, dict):
        content = item.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            chunks = [
                block.get("text", "")
                for block in content
                if isinstance(block, dict) and isinstance(block.get("text"), str)
            ]
            return " ".join(chunks)
    return ""


def _approval_state_for_subagents(subagents: list[SubagentConfig]) -> HumanApprovalState:
    """Return a pending approval state for subagents that require manager sign-off."""
    applicable = [subagent for subagent in subagents if subagent.requires_human_approval]
    if not applicable:
        return HumanApprovalState(status="not_required", required=False)

    return HumanApprovalState(
        status="pending",
        required=True,
        approver="manager",
        reason=(
            "Human approval required before any operational action can be recommended. "
            "Prepare the intervention packet and wait for manager sign-off."
        ),
    )


def _append_approval_message_to_output_items(
    output_items: list[dict[str, Any]],
    approval: HumanApprovalState,
) -> list[dict[str, Any]]:
    """Append a manager-review footer to the last assistant message when approval is pending."""
    if not approval.required or approval.status != "pending":
        return output_items

    message = (
        "\n\nApproval required: this recommendation is pending manager review before any "
        "operational action or dispatch recommendation is sent."
    )
    updated = [dict(item) for item in output_items]
    for item in reversed(updated):
        if item.get("role") != "assistant":
            continue
        content = item.get("content")
        if isinstance(content, str):
            item["content"] = content + message
            return updated
        if isinstance(content, list):
            blocks: list[Any] = [dict(block) if isinstance(block, dict) else block for block in content]
            for block in reversed(blocks):
                if isinstance(block, dict) and isinstance(block.get("text"), str):
                    block["text"] = block["text"] + message
                    item["content"] = blocks
                    return updated
            blocks.append({"type": "output_text", "text": message.strip()})
            item["content"] = blocks
            return updated
    updated.append({"role": "assistant", "content": message.strip()})
    return updated


def _guardrail_block_message(reasons: tuple[str, ...]) -> str:
    """Format a safe, user-facing explanation for blocked responses."""
    reason_list = ", ".join(reasons) if reasons else "policy_check_failed"
    return (
        "I couldn't return the answer because the response was blocked by a guardrail "
        f"({reason_list}). For `evidence_required`, ask the agent to include a citation "
        "such as `[1]` or an explicit `Source:` line."
    )


def _user_error_failure_reason(exc: UserError) -> str:
    """Classify user-facing runtime errors for lifecycle audit events."""
    return "guardrail" if "guardrail" in str(exc).lower() else "authorization"


def _candidate_tool_names(data: dict[str, Any]) -> list[str]:
    """Extract candidate tool or subagent names from event or output-item data."""
    candidates: list[str] = []
    for key in ("name", "tool_name"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            candidates.append(value.strip())

    item = data.get("item")
    if isinstance(item, dict):
        for key in ("name", "tool_name"):
            value = item.get(key)
            if isinstance(value, str) and value.strip():
                candidates.append(value.strip())

    return candidates


def _resolve_subagent(candidate: str, subagents: list[SubagentConfig]) -> SubagentConfig | None:
    """Map a streamed tool identifier back to a configured subagent."""
    normalized = candidate.strip()
    if normalized.startswith("query_"):
        normalized = normalized[len("query_") :]
    elif normalized.startswith("Genie:"):
        normalized = normalized.split(":", 1)[1]
    elif normalized.startswith("MCP:"):
        normalized = normalized.split(":", 1)[1]

    for subagent in subagents:
        if normalized in {subagent.name, subagent.tool_name}:
            return subagent
    return None


def _used_subagents_from_payloads(
    payloads: list[dict[str, Any]],
    subagents: list[SubagentConfig],
) -> list[SubagentConfig]:
    """Collect the distinct configured subagents referenced in events or output items."""
    ordered: list[SubagentConfig] = []
    seen: set[str] = set()

    for payload in payloads:
        for candidate in _candidate_tool_names(payload):
            subagent = _resolve_subagent(candidate, subagents)
            if subagent is None or subagent.name in seen:
                continue
            seen.add(subagent.name)
            ordered.append(subagent)

    return ordered


def _governed_source_suffix(used_subagents: list[SubagentConfig]) -> str:
    """Build a deterministic source footer for governed tool-backed answers."""
    governed = [subagent for subagent in used_subagents if subagent.requires_evidence]
    if not governed:
        return ""

    parts: list[str] = []
    for subagent in governed:
        tool_type = "Genie MCP" if subagent.is_genie else subagent.kind.replace("_", " ")
        freshness = subagent.freshness_sla or "unknown freshness"
        parts.append(f"{subagent.name} ({tool_type}, freshness {freshness})")

    return "\n\nSource: " + "; ".join(parts)


def _event_has_tool_activity(payloads: list[dict[str, Any]]) -> bool:
    """Return true when stream/output payloads show any tool execution activity."""
    for payload in payloads:
        if _payload_has_tool_activity(payload):
            return True

    return False


def _payload_has_tool_activity(payload: dict[str, Any]) -> bool:
    """Return true when a single event/output payload indicates tool activity."""
    event_type = payload.get("type")
    if isinstance(event_type, str) and (
        event_type.startswith("response.output_item")
        or "tool" in event_type
        or "mcp" in event_type
        or "function_call" in event_type
    ):
        item = payload.get("item")
        if isinstance(item, dict):
            item_type = item.get("type")
            if isinstance(item_type, str) and (
                "tool" in item_type or "mcp" in item_type or "function_call" in item_type
            ):
                return True
        elif "tool" in event_type or "mcp" in event_type or "function_call" in event_type:
            return True

    item = payload.get("item")
    if isinstance(item, dict):
        item_type = item.get("type")
        if isinstance(item_type, str) and (
            "tool" in item_type or "mcp" in item_type or "function_call" in item_type
        ):
            return True

    return False


def _governed_source_suffix_with_fallback(
    payloads: list[dict[str, Any]],
    subagents: list[SubagentConfig],
) -> str:
    """Build a governed source suffix with a fallback for unlabelled tool events."""
    used_subagents = _used_subagents_from_payloads(payloads, subagents)
    suffix = _governed_source_suffix(used_subagents)
    if suffix:
        return suffix

    governed = [subagent for subagent in subagents if subagent.requires_evidence]
    if governed and _event_has_tool_activity(payloads):
        return "\n\nSource: tool-backed governed response."

    if governed:
        return "\n\nSource: governed response; source metadata was unavailable in the final output item."

    return ""


def _guardrail_scope_subagents(
    payloads: list[dict[str, Any]],
    subagents: list[SubagentConfig],
) -> list[SubagentConfig]:
    """Limit guardrail checks to subagents that likely contributed to the answer."""
    used_subagents = _used_subagents_from_payloads(payloads, subagents)
    if used_subagents:
        return used_subagents

    if _event_has_tool_activity(payloads):
        return [subagent for subagent in subagents if subagent.requires_evidence]

    return []


def _append_source_to_output_items(
    output_items: list[dict[str, Any]],
    source_suffix: str,
) -> list[dict[str, Any]]:
    """Append a source footer to the last assistant message item."""
    if not source_suffix:
        return output_items

    updated = [dict(item) for item in output_items]
    for item in reversed(updated):
        if item.get("role") != "assistant":
            continue

        content = item.get("content")
        if isinstance(content, str):
            item["content"] = content + source_suffix
            return updated

        if isinstance(content, list):
            mutable_blocks: list[Any] = []
            appended = False
            for block in content:
                if isinstance(block, dict):
                    mutable_blocks.append(dict(block))
                else:
                    mutable_blocks.append(block)
            for block in reversed(mutable_blocks):
                if isinstance(block, dict) and isinstance(block.get("text"), str):
                    block["text"] = block["text"] + source_suffix
                    appended = True
                    break
            if not appended:
                mutable_blocks.append({"type": "output_text", "text": source_suffix.strip()})
            item["content"] = mutable_blocks
            return updated

    return output_items


def _publish_openai_run_completed(envelope: ResponseEnvelope) -> None:
    """Publish final OpenAI-compatible run metadata with response policy outcome."""
    HANDLER_DEPS.message_bus.publish(
        "openai.agent.run.completed",
        {
            **asdict(envelope.openai_run),
            "status": envelope.status,
            "guardrail_reasons": list(envelope.guardrail_reasons),
            "answer_chars": envelope.answer_chars,
        },
    )


def _truncate_output_items(
    output_items: list[dict[str, Any]],
    *,
    max_response_chars: int,
) -> list[dict[str, Any]]:
    """Apply the response budget to the returned assistant content."""
    updated = [dict(item) for item in output_items]
    for item in reversed(updated):
        if item.get("role") != "assistant":
            continue
        content = item.get("content")
        if isinstance(content, str):
            item["content"], _ = truncate_response_text(
                content,
                max_response_chars=max_response_chars,
            )
            return updated
        if isinstance(content, list):
            for block in reversed(content):
                if isinstance(block, dict) and isinstance(block.get("text"), str):
                    block["text"], _ = truncate_response_text(
                        block["text"],
                        max_response_chars=max_response_chars,
                    )
                    return updated
    return output_items


@invoke()
async def invoke_handler(request: ResponsesAgentRequest) -> ResponsesAgentResponse:
    HANDLER_DEPS.message_bus.publish(
        "request.invoke.started",
        {
            "subagents_total": len(SUBAGENTS),
        },
    )
    conversation_id = get_session_id(request)
    _apply_remembered_persona(request, conversation_id)
    _restore_conversation_memory(request, conversation_id)
    prepared = _prepare_request_stage(request)
    persona = _request_persona(request)

    try:
        async with AsyncExitStack() as stack:
            connected = await _connect_request_stage(stack, prepared)
            result = await _execute_invoke_stage(connected, prepared.messages)
            finalized = _finalize_invoke_stage(result, connected)
            _persist_memory_turns(
                conversation_id,
                persona,
                question=_extract_user_question(prepared.messages),
                answer=_extract_last_assistant_text(finalized.output_items),
            )
            HANDLER_DEPS.message_bus.publish(
                "request.invoke.succeeded",
                {
                    "output_items": len(result.new_items),
                    "unavailable_tools": len(finalized.unavailable),
                    "unavailable_tool_details": finalized.unavailable,
                    "response_envelope": asdict(finalized.envelope),
                },
            )
            _publish_openai_run_completed(finalized.envelope)
            return ResponsesAgentResponse(output=cast(Any, finalized.output_items))
    except UserError as e:
        HANDLER_DEPS.message_bus.publish(
            "request.invoke.failed",
            {
                "error_type": type(e).__name__,
                "reason": _user_error_failure_reason(e),
            },
        )
        logger.warning("Authorization error during invoke: %s", e)
        raise
    except Exception as e:
        HANDLER_DEPS.message_bus.publish(
            "request.invoke.failed",
            {
                "error_type": type(e).__name__,
            },
        )
        mcp_errors = extract_mcp_errors(e)
        if mcp_errors:
            logger.warning(
                "MCP tool error during invoke: %s",
                "; ".join(str(x) for x in mcp_errors),
            )
        raise


@stream()
async def stream_handler(
    request: ResponsesAgentRequest,
) -> AsyncGenerator[ResponsesAgentStreamEvent, None]:
    started_at = monotonic()
    HANDLER_DEPS.message_bus.publish(
        "request.stream.started",
        {
            "subagents_total": len(SUBAGENTS),
        },
    )
    yield _stream_progress_event("accepted")

    try:
        async with asyncio.timeout(SETTINGS.stream_execution_timeout_seconds):
            conversation_id = get_session_id(request)
            _apply_remembered_persona(request, conversation_id)
            _restore_conversation_memory(request, conversation_id)
            prepared = _prepare_request_stage(request)
            persona = _request_persona(request)
            _publish_stream_stage("prepared", started_at)
            yield _stream_progress_event("prepared")

            async with AsyncExitStack() as stack:
                connected = await _connect_request_stage(stack, prepared)
                _publish_stream_stage("connected", started_at)
                yield _stream_progress_event("executing")
                executed = await _execute_stream_stage(connected, prepared.messages)
                _publish_stream_stage("executed", started_at)
                yield _stream_progress_event("finalizing")
                finalized = _finalize_stream_stage(executed, connected)
                if finalized.guardrail_blocked:
                    yield cast(
                        Any,
                        {
                            "type": "response.output_text.delta",
                            "item_id": "item_guardrail",
                            "delta": _guardrail_block_message(finalized.guardrail_reasons),
                        },
                    )
                    _publish_openai_run_completed(finalized.envelope)
                    HANDLER_DEPS.message_bus.publish(
                        "request.stream.failed",
                        {
                            "error_type": "UserError",
                            "reason": "guardrail",
                        },
                    )
                    return

                for event in finalized.buffered_events:
                    yield event
                yield cast(
                    Any,
                    {
                        "type": "response.governance",
                        "response_envelope": asdict(finalized.envelope),
                    },
                )
                if finalized.source_suffix:
                    yield cast(
                        Any,
                        {
                            "type": "response.output_text.delta",
                            "item_id": "item_source",
                            "delta": finalized.source_suffix,
                        },
                    )
                _persist_memory_turns(
                    conversation_id,
                    persona,
                    question=_extract_user_question(prepared.messages),
                    answer="".join(executed.streamed_text_parts) + finalized.source_suffix,
                )
                HANDLER_DEPS.message_bus.publish(
                    "request.stream.succeeded",
                    {
                        "events_streamed": finalized.event_count,
                        "unavailable_tools": len(finalized.unavailable),
                        "unavailable_tool_details": finalized.unavailable,
                        "response_envelope": asdict(finalized.envelope),
                        "elapsed_ms": (monotonic() - started_at) * 1000,
                    },
                )
                _publish_openai_run_completed(finalized.envelope)
    except TimeoutError:
        HANDLER_DEPS.message_bus.publish(
            "request.stream.failed",
            {
                "error_type": "TimeoutError",
                "reason": "stream_execution_timeout",
                "elapsed_ms": (monotonic() - started_at) * 1000,
            },
        )
        logger.warning("Stream execution exceeded %.1f seconds", SETTINGS.stream_execution_timeout_seconds)
        yield cast(
            Any,
            {
                "type": "response.output_text.delta",
                "item_id": "item_timeout",
                "delta": "This request took too long to complete. Please retry or narrow the request.",
            },
        )
        return
    except asyncio.CancelledError:
        HANDLER_DEPS.message_bus.publish(
            "request.stream.client_disconnected",
            {
                "elapsed_ms": (monotonic() - started_at) * 1000,
            },
        )
        logger.info("Client disconnected during streamed request")
        raise
    except UserError as e:
        HANDLER_DEPS.message_bus.publish(
            "request.stream.failed",
            {
                "error_type": type(e).__name__,
                "reason": "authorization",
                "elapsed_ms": (monotonic() - started_at) * 1000,
            },
        )
        logger.warning("Authorization error during stream: %s", e)
        raise
    except Exception as e:
        HANDLER_DEPS.message_bus.publish(
            "request.stream.failed",
            {
                "error_type": type(e).__name__,
                "elapsed_ms": (monotonic() - started_at) * 1000,
            },
        )
        mcp_errors = extract_mcp_errors(e)
        if mcp_errors:
            logger.warning(
                "MCP tool error during stream: %s",
                "; ".join(str(x) for x in mcp_errors),
            )
            yield cast(
                Any,
                {
                    "type": "response.output_text.delta",
                    "item_id": "item_error",
                    "delta": (
                        "I couldn't complete this request because a connected "
                        "assistant or data source was unavailable. Please try again."
                    ),
                },
            )
            return
        logger.exception("Unhandled stream execution failure")
        yield cast(
            Any,
            {
                "type": "response.output_text.delta",
                "item_id": "item_error",
                "delta": (
                    "I couldn't complete this request because the backend "
                    "or a connected data source failed. Please try again."
                ),
            },
        )
        return
